from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config['SECRET_KEY'] = '7d9b9795c9af7341c94dc837d8f661ec'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config['SQLAlCHEMY_TRACK-MODIFICATIONS'] = False

db = SQLAlchemy(app)

from Flaskblog import routes